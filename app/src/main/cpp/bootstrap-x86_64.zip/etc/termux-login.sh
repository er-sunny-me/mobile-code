##
## This script is sourced by /data/data/com.xyzide/files/usr/bin/login before executing shell.
##

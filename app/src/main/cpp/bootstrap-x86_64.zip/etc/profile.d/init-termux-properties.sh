if [ ! -f /data/data/com.xyzide/files/home/.config/termux/termux.properties ] && [ ! -e /data/data/com.xyzide/files/home/.termux/termux.properties ]; then
	mkdir -p /data/data/com.xyzide/files/home/.termux
	cp /data/data/com.xyzide/files/usr/share/examples/termux/termux.properties /data/data/com.xyzide/files/home/.termux/
fi
